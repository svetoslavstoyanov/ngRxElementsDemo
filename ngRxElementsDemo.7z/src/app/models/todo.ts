export interface ITodo {
    todo: string;
}
